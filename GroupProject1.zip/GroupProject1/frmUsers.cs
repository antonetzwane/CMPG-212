﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject1
{
    public partial class frmSpecials : Form
    {
        public frmSpecials()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //When the button is clicked the frmOrders must be displayed.
            frmReceipt orders = new frmReceipt();
            orders.ShowDialog();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //When the button is clicked the frmStaffLogin must be displayed.
            frmStaffLogin staffItems = new frmStaffLogin();
            staffItems.ShowDialog();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //To hide the web Form and not close the whole program when executed.
            this.Hide();
            //When log Out is clicked, the welcome page/form must be displayed.
            Form1 welcomepage = new Form1();
            welcomepage.ShowDialog();
        }

        private void btnInsertItems_Click(object sender, EventArgs e)
        {
            string Staffname = "Staff";
            string password = "1243BC";
            //string insert = "Insert into Table name values("" + txtName.Text + '", '" + txtPassword)";
            //SqlCommand comm = new SqlCommand(conn,insert );
            //comm.ExecuteNonQuery();
            //MessageBox.Show("Successfully Created.");

        }

        private void dataGridManage_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
