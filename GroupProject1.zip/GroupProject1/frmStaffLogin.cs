﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject1
{
    public partial class frmStaffLogin : Form
    {
        //declare global variables
        SqlCommand cmd;
        DataSet ds;
        SqlDataAdapter adapter;
        //String connectionString;
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataMenu.mdf;Integrated Security=True");
        public frmStaffLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            //When button is clicked, the frmOrders form must be displayed.
            frmReceipt od = new frmReceipt();
            od.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            //To hide the web Form and not close the whole program when executed.
            this.Hide();
            //When this is clicked, the welcome page/Form1 must be displayed.
            Form1 welcomePage = new Form1();
            welcomePage.ShowDialog();
        }

        private void btnInsertItems_Click(object sender, EventArgs e)
        {
            //insert new items.
            String ItemNumber, ItemName, ItemPrice;

            ItemNumber = txtItemNumber.Text;
            ItemName = txtItemName.Text;
            ItemPrice = txtItemPrice.Text;

            try
            {
                con.Open(); //open the connection
                //Code for the staff to insert items(food) that are in stock and that must be sold.
                string insert = "INSERT into Menu VALUES (' " + txtItemNumber.Text +" ',' " + txtItemName.Text+" ', '"+txtItemPrice.Text+"')";
                SqlCommand comm = new SqlCommand(insert, con);
                adapter = new SqlDataAdapter();
                InsertForm();//Calling the insert form for update the database.
                con.Close();

                con.Open();
                adapter.InsertCommand = comm;
                adapter.InsertCommand.ExecuteNonQuery();
                MessageBox.Show("items successfully inserted");

                //Code for the staff to insert items(drinks) that are in stock and that must be sold.
                string insertDrinks = "INSERT into Menu VALUES (' " + txtItemNumber.Text + " ',' " + txtItemName.Text + " ', '" + txtItemPrice.Text + "')";
                SqlCommand com = new SqlCommand(insertDrinks, con);
                adapter = new SqlDataAdapter();

                adapter.InsertCommand = com;
                adapter.InsertCommand.ExecuteNonQuery();

                MessageBox.Show("items successfully inserted");
                InsertFormDrinks();//Calling the insert form for update the database.
                con.Close();
                

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                txtItemName.Clear();
                txtItemNumber.Clear();
                txtItemPrice.Clear();
            }

        }

        private void btnDeleteItems_Click(object sender, EventArgs e)
        {
            //delete items
            try
            {
                //Code for deleting an item(food) according to its name.
                con.Open();
                string deleteFood = $"DELETE FROM Menu WHERE SandwichesPastries ='" + txtItemName.Text  + "'";
                SqlCommand comm = new SqlCommand(deleteFood, con);
                adapter = new SqlDataAdapter();

                adapter.DeleteCommand = comm;
                adapter.DeleteCommand.ExecuteNonQuery();
            
                con.Close();
                DeleteForm();//Calling the delete form for update the database.

                con.Open();
                //Code for deleting an item(drinks) according to its name.
                string deleteDrinks = $"DELETE FROM MenuDrinks WHERE CoffeeTea ='" + txtItemName.Text + "'";
                SqlCommand comma = new SqlCommand(deleteDrinks, con);
                adapter = new SqlDataAdapter();

                adapter.DeleteCommand = comm;
                adapter.DeleteCommand.ExecuteNonQuery();

                DeleteFormDrinks();//Calling the delete form for update the database.
                con.Close();
               

            }
            catch (SqlException ex)

            {
                MessageBox.Show(ex.Message);

            }
        }

        private void btnUpdateItens_Click(object sender, EventArgs e)
        {
            //update items 
            try
            {
                //Update an item on the datagridview for food.
                con.Open();
                string updateFood = $"UPDATE Menu set SandwichesPastries ='" + txtItemName.Text + "' where SandwichesPastries= ' " + txtItemPrice.Text + " ' ";
                SqlCommand comm = new SqlCommand(updateFood, con);

                adapter.UpdateCommand = comm;
                adapter.UpdateCommand.ExecuteNonQuery();
                MessageBox.Show("Items updated successfully");
                con.Close();

                //Update an item on the datagridview for food.
                con.Open();
                string updateDrinks = $"UPDATE MenuDrinks set CoffeeTea ='" + txtItemName.Text + "'where CoffeeTea= ' " + txtItemPrice.Text + " ' ";
                SqlCommand comma = new SqlCommand(updateDrinks, con);
                adapter = new SqlDataAdapter();

                adapter.UpdateCommand = comma;
                adapter.UpdateCommand.ExecuteNonQuery();
                con.Close();

            }
            catch (SqlException ex)

            {
                MessageBox.Show(ex.Message);

            }

        }

        private void rdbDrinks_CheckedChanged(object sender, EventArgs e)
        {
            //Display table/menu for food when this radiobutton is clicked.
            try
            {
                con.Open();
                string food = @"SELECT *FROM MenuDrinks";
                SqlCommand comm = new SqlCommand(food, con);
                ds = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = comm;
                adapter.Fill(ds, "MenuDrinks");

                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "MenuDrinks";

                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void rdbFood2_CheckedChanged(object sender, EventArgs e)
        {
            //Display table/menu for drinks when this radiobutton is clicked.
            try
            {
                con.Open();
                string food = @"SELECT *FROM Menu";
                SqlCommand comm = new SqlCommand(food, con);
                ds = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = comm;
                adapter.Fill(ds, "Menu");

                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "Menu";

                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnSpecials_Click(object sender, EventArgs e)
        {
            // specials form

            frmSpecials myspecial = new frmSpecials();
            myspecial.ShowDialog();
        }
        public void DeleteForm()
        {
            //Updating the delete form after deleting an item.
            try
            {
                con.Open();
                string delete = @"SELECT *FROM Menu";
                cmd = new SqlCommand(delete, con);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = cmd;
                adapter.Fill(ds, "Menu");
                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "Menu";
                con.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        public void DeleteFormDrinks()
        {
            //Updating the delete form after deleting an item.
            try
            {
                con.Open();
                string delete = @"SELECT *FROM MenuDrinks";
                cmd = new SqlCommand(delete, con);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = cmd;
                adapter.Fill(ds, "MenuDrinks");
                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "MenuDrinks";
                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        public void InsertForm()
        {
            //Updating the delete form after deleting an item.
            try
            {
                con.Open();
                string delete = @"SELECT *FROM Menu";
                cmd = new SqlCommand(delete, con);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = cmd;
                adapter.Fill(ds, "Menu");
                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "Menu";
                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        public void InsertFormDrinks()
        {
            //Updating the delete form after deleting an item.
            try
            {
                con.Open();
                string delete = @"SELECT *FROM MenuDrinks";
                cmd = new SqlCommand(delete, con);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = cmd;
                adapter.Fill(ds, "MenuDrinks");
                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "MenuDrinks";
                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        public void UpdateForm()
        {
            //Updating the delete form after deleting an item.
            try
            {
                con.Open();
                string delete = @"SELECT *FROM Menu";
                cmd = new SqlCommand(delete, con);
                adapter = new SqlDataAdapter();
                ds = new DataSet();

                adapter.SelectCommand = cmd;
                adapter.Fill(ds, "Menu");
                dataGridManage.DataSource = ds;
                dataGridManage.DataMember = "Menu";
                con.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }

} 

    

