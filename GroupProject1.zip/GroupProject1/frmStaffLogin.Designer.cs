﻿namespace GroupProject1
{
    partial class frmStaffLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtItemName = new System.Windows.Forms.TextBox();
            this.txtItemNumber = new System.Windows.Forms.TextBox();
            this.btnInsertItems = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtItemPrice = new System.Windows.Forms.TextBox();
            this.dataGridManage = new System.Windows.Forms.DataGridView();
            this.btnDeleteItems = new System.Windows.Forms.Button();
            this.btnUpdateItens = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.rdbDrinks = new System.Windows.Forms.RadioButton();
            this.rdbFood2 = new System.Windows.Forms.RadioButton();
            this.btnSpecials = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridManage)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(176, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(406, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Administration and Management Of Items";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(56, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(105, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Item Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(59, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(109, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name of Item:";
            // 
            // txtItemName
            // 
            this.txtItemName.Location = new System.Drawing.Point(193, 216);
            this.txtItemName.Name = "txtItemName";
            this.txtItemName.Size = new System.Drawing.Size(128, 20);
            this.txtItemName.TabIndex = 3;
            // 
            // txtItemNumber
            // 
            this.txtItemNumber.Location = new System.Drawing.Point(193, 145);
            this.txtItemNumber.Name = "txtItemNumber";
            this.txtItemNumber.Size = new System.Drawing.Size(128, 20);
            this.txtItemNumber.TabIndex = 4;
            // 
            // btnInsertItems
            // 
            this.btnInsertItems.BackColor = System.Drawing.Color.Black;
            this.btnInsertItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInsertItems.ForeColor = System.Drawing.Color.Transparent;
            this.btnInsertItems.Location = new System.Drawing.Point(48, 375);
            this.btnInsertItems.Name = "btnInsertItems";
            this.btnInsertItems.Size = new System.Drawing.Size(120, 37);
            this.btnInsertItems.TabIndex = 5;
            this.btnInsertItems.Text = "Insert";
            this.btnInsertItems.UseVisualStyleBackColor = false;
            this.btnInsertItems.Click += new System.EventHandler(this.btnInsertItems_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Transparent;
            this.label4.Location = new System.Drawing.Point(59, 284);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 20);
            this.label4.TabIndex = 6;
            this.label4.Text = "Price of Item:";
            // 
            // txtItemPrice
            // 
            this.txtItemPrice.Location = new System.Drawing.Point(193, 284);
            this.txtItemPrice.Name = "txtItemPrice";
            this.txtItemPrice.Size = new System.Drawing.Size(128, 20);
            this.txtItemPrice.TabIndex = 7;
            // 
            // dataGridManage
            // 
            this.dataGridManage.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridManage.Location = new System.Drawing.Point(373, 54);
            this.dataGridManage.Name = "dataGridManage";
            this.dataGridManage.Size = new System.Drawing.Size(382, 235);
            this.dataGridManage.TabIndex = 8;
            // 
            // btnDeleteItems
            // 
            this.btnDeleteItems.BackColor = System.Drawing.Color.Black;
            this.btnDeleteItems.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteItems.ForeColor = System.Drawing.Color.Transparent;
            this.btnDeleteItems.Location = new System.Drawing.Point(210, 375);
            this.btnDeleteItems.Name = "btnDeleteItems";
            this.btnDeleteItems.Size = new System.Drawing.Size(120, 37);
            this.btnDeleteItems.TabIndex = 9;
            this.btnDeleteItems.Text = "Delete";
            this.btnDeleteItems.UseVisualStyleBackColor = false;
            this.btnDeleteItems.Click += new System.EventHandler(this.btnDeleteItems_Click);
            // 
            // btnUpdateItens
            // 
            this.btnUpdateItens.BackColor = System.Drawing.Color.Black;
            this.btnUpdateItens.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateItens.ForeColor = System.Drawing.Color.Transparent;
            this.btnUpdateItens.Location = new System.Drawing.Point(384, 375);
            this.btnUpdateItens.Name = "btnUpdateItens";
            this.btnUpdateItens.Size = new System.Drawing.Size(120, 37);
            this.btnUpdateItens.TabIndex = 10;
            this.btnUpdateItens.Text = "Update";
            this.btnUpdateItens.UseVisualStyleBackColor = false;
            this.btnUpdateItens.Click += new System.EventHandler(this.btnUpdateItens_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Transparent;
            this.label6.Location = new System.Drawing.Point(709, 410);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 20);
            this.label6.TabIndex = 14;
            this.label6.Text = "Log Out";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // rdbDrinks
            // 
            this.rdbDrinks.AutoSize = true;
            this.rdbDrinks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbDrinks.ForeColor = System.Drawing.Color.Transparent;
            this.rdbDrinks.Location = new System.Drawing.Point(63, 71);
            this.rdbDrinks.Name = "rdbDrinks";
            this.rdbDrinks.Size = new System.Drawing.Size(103, 24);
            this.rdbDrinks.TabIndex = 15;
            this.rdbDrinks.TabStop = true;
            this.rdbDrinks.Text = "Beverages";
            this.rdbDrinks.UseVisualStyleBackColor = true;
            this.rdbDrinks.CheckedChanged += new System.EventHandler(this.rdbDrinks_CheckedChanged);
            // 
            // rdbFood2
            // 
            this.rdbFood2.AutoSize = true;
            this.rdbFood2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdbFood2.ForeColor = System.Drawing.Color.Transparent;
            this.rdbFood2.Location = new System.Drawing.Point(210, 71);
            this.rdbFood2.Name = "rdbFood2";
            this.rdbFood2.Size = new System.Drawing.Size(64, 24);
            this.rdbFood2.TabIndex = 16;
            this.rdbFood2.TabStop = true;
            this.rdbFood2.Text = "Food";
            this.rdbFood2.UseVisualStyleBackColor = true;
            this.rdbFood2.CheckedChanged += new System.EventHandler(this.rdbFood2_CheckedChanged);
            // 
            // btnSpecials
            // 
            this.btnSpecials.BackColor = System.Drawing.Color.Black;
            this.btnSpecials.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSpecials.ForeColor = System.Drawing.Color.Transparent;
            this.btnSpecials.Location = new System.Drawing.Point(556, 375);
            this.btnSpecials.Name = "btnSpecials";
            this.btnSpecials.Size = new System.Drawing.Size(120, 37);
            this.btnSpecials.TabIndex = 17;
            this.btnSpecials.Text = "Specials";
            this.btnSpecials.UseVisualStyleBackColor = false;
            this.btnSpecials.Click += new System.EventHandler(this.btnSpecials_Click);
            // 
            // frmStaffLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Peru;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSpecials);
            this.Controls.Add(this.rdbFood2);
            this.Controls.Add(this.rdbDrinks);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.btnUpdateItens);
            this.Controls.Add(this.btnDeleteItems);
            this.Controls.Add(this.dataGridManage);
            this.Controls.Add(this.txtItemPrice);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnInsertItems);
            this.Controls.Add(this.txtItemNumber);
            this.Controls.Add(this.txtItemName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "frmStaffLogin";
            this.Text = "frmStaffLogin";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridManage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtItemName;
        private System.Windows.Forms.TextBox txtItemNumber;
        private System.Windows.Forms.Button btnInsertItems;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtItemPrice;
        private System.Windows.Forms.DataGridView dataGridManage;
        private System.Windows.Forms.Button btnDeleteItems;
        private System.Windows.Forms.Button btnUpdateItens;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rdbDrinks;
        private System.Windows.Forms.RadioButton rdbFood2;
        private System.Windows.Forms.Button btnSpecials;
    }
}