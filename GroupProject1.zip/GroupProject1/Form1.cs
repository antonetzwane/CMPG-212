﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject1
{
    public partial class Form1 : Form
    {
        //41509056 Antonet Zwane
        // 39774406 D Chauke.
        DataSet data;
        SqlDataAdapter adapter;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""D:\CMPG 212\GroupProject1\DataMenu.mdf"";Integrated Security=True");
        public Form1()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Hide();
            //When customer is clicked the customer for/frmCustomers must be displayed.
            frmCustomers customer = new frmCustomers();
            customer.ShowDialog();
        }

        private void btnStaffLogin_Click(object sender, EventArgs e)
        {
            String loginName;
            String password;

            loginName = txtName.Text;
            password = txtPassword.Text;
            try
            {
                String login = "SELECT *FROM StaffLogin WHERE loginName = '" + txtName.Text + "' AND password =' " + txtPassword.Text + "'";
                adapter = new SqlDataAdapter(login, conn);
                data = new DataSet();

                DataTable dtable = new DataTable();
                adapter.Fill(dtable);

                if(dtable.Rows.Count >= 0)
                {
                   // loginName = txtName.Text;
                   // password = txtPassword.Text;

                    frmStaffLogin log = new frmStaffLogin();
                    //log.Show();
                    this.Hide();
                    log.Show();
                }
                else
                {
                    MessageBox.Show("Invalid username or password.");
                    txtPassword.Clear();
                    txtName.Clear();

                    txtName.Focus();
                }

            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
