﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GroupProject1
{
    public partial class frmCustomers : Form
    {
        public double total;
        public double price;
        int number = 0;
        DataSet ds;
        SqlDataAdapter adapter;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataMenu.mdf;Integrated Security=True");
        public frmCustomers()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            //To hide the web Form and not close the whole program when executed.
            this.Hide();
            //When logout is clicked, the program must take us back to the welcome form/first form.
            Form1 welcomePage = new Form1();
            welcomePage.ShowDialog();
        }

        private void frmCustomers_Load(object sender, EventArgs e)
        {
            
        }

        private void dataGridMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void rdbBeverages_CheckedChanged(object sender, EventArgs e)
        {
            
            try
            {
                conn.Open();
                string food = @"SELECT *FROM MenuDrinks";
                SqlCommand comm = new SqlCommand(food, conn);
                ds = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = comm;
                adapter.Fill(ds, "MenuDrinks");

                dataGridMenu.DataSource = ds;
                dataGridMenu.DataMember = "MenuDrinks";

                conn.Close();
            }
             catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void rdbFood_CheckedChanged(object sender, EventArgs e)
        {
            
            try
            {
                conn.Open();
                string food = @"SELECT *FROM Menu";
                SqlCommand comm = new SqlCommand(food, conn);
                ds = new DataSet();
                adapter = new SqlDataAdapter();

                adapter.SelectCommand = comm;
                adapter.Fill(ds, "Menu");

                dataGridMenu.DataSource = ds;
                dataGridMenu.DataMember = "Menu";

                conn.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void listMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            //remove items from the listbox.
            if (listMenu.SelectedItem != null)
            {
                listMenu.Items.Remove(listMenu.SelectedItem);

                listMenu.Items.Add("This item is removed from your order.");
            }
        }

        private void dataGridMenu_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //When the customer selects an item on a dataGridMenu it must display on the listbox.
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow selectedRow = this.dataGridMenu.Rows[e.RowIndex];
                    listMenu.Items.Add(selectedRow.Cells[0].Value.ToString() + "\t" + selectedRow.Cells[1].Value.ToString() + "\t" + selectedRow.Cells[2].Value.ToString());
                    
                }
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridMenu_SelectionChanged(object sender, EventArgs e)
        {

        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            //When button order is clicked the receipt must be displayed.
            frmReceipt receipt = new frmReceipt();
            receipt.ShowDialog();

            int count = dataGridMenu.SelectedRows.Count;
            int i = 0;

            if (rdbFood.Checked == true)
            {
                while (i < count)
                {
                    DataGridViewRow row = dataGridMenu.SelectedRows[i];

                    price = Convert.ToDouble(row.Cells["Price"].Value);

                    total += price + Convert.ToDouble(row.Cells["Price"].Value);
                    i++;
                }
            }
            else if (rdbBeverages.Checked == true)
            {
                while (i < count)
                {
                    DataGridViewRow row = dataGridMenu.SelectedRows[i];

                    price = Convert.ToDouble(row.Cells["Prices"].Value);

                    total += price + Convert.ToDouble(row.Cells["Prices"].Value);
                    i++;
                }
            }

            List<string> selectedItems = new List<string>();
            foreach (var item in listMenu.SelectedItems)
            {
                selectedItems.Add(item.ToString());
            }

            // Set the retrieved items to the property of the second form
            receipt.SelectedItems = selectedItems;

            // Show the second form
            receipt.Show();
        }
    }
}
