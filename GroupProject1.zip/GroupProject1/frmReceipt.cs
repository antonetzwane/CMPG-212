﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GroupProject1
{
    public partial class frmReceipt : Form
    {
        public List<string> SelectedItems { get; set; }
        public frmReceipt()
        {
            InitializeComponent();
        }
        public string Value { get; set; }

        private void label1_Click(object sender, EventArgs e)
        {
            //To hide the web Form and not close the whole program when executed.
            this.Hide();
            //When logout is clicked, the program must take us back to the welcome form/first form.
            Form1 welcomePage = new Form1();
            welcomePage.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            //When button Items is clicked, the frmStaffLogin form must be displayed.
            frmStaffLogin staffLogin = new frmStaffLogin();
            staffLogin.ShowDialog();
        }

        private void btnUsersItems_Click(object sender, EventArgs e)
        {
            this.Hide();
            //When button Items is clicked, the frmUsers form must be displayed.
            frmSpecials users = new frmSpecials();
            users.ShowDialog();
        }

        private void btnOrder_Click(object sender, EventArgs e)
        {
            
        }



        private void listReceipt_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void frmReceipt_Load(object sender, EventArgs e)
        {
            //The receipt that must be displayed.
            listReceipt.Items.Add("Beelte Caf.");
            listReceipt.Items.Add("*****************************");
            listReceipt.Items.Add("HERE IS YOUR RECEIPT.");
            listReceipt.Items.Add("*****************************");
            listReceipt.Items.Add("ItemName ****************************");
            listReceipt.Items.Add("Item bought");
            listReceipt.Items.Add("Item bought");
            listReceipt.Items.Add("The total price is  R");
            listReceipt.Items.Add("Thank you for purchasing at our store!!!");
        }
        public void Receipt()
        {
            
        }

    }
}

