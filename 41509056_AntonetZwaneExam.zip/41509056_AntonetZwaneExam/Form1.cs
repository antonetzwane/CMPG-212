﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _41509056_AntonetZwaneExam
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //An if statement to validate the login.
            if(txtUName.Text == "" || txtUPassword.Text == "")
            {
                MessageBox.Show("Enter a valid username or password.");
            }
            else
            {
                //When the button login is clicked, frmUserDashboard must be displayed.
                frmUserDashboard dashboard = new frmUserDashboard();
                dashboard.ShowDialog();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
