﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace _41509056_AntonetZwaneExam
{
    public partial class frmHostManage : Form
    {
        //Connecting the database.
        DataSet dtset;
        SqlDataAdapter adapter;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True");

        //Declaring variables that are going to be used in the programe.
        public int eventID;
        public string eventName;
        public string eventDescri;
        public int eventTime;
        public string eventDate;
        public string eventVenue;
        public int eventCapacity;
        public string eventAdditional;
        public frmHostManage()
        {
            InitializeComponent();
        }

        private void frmHostManage_Load(object sender, EventArgs e)
        {
            //Connecting the database.
            string connectData;
            connectData = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True";
            conn = new SqlConnection(connectData);

            //Setting the textboxes into variables and validating them.
            int.TryParse(txtEventID.Text, out eventID);
            eventName = txtEventName.Text;
            eventDescri = txtEventDescription.Text;
            int.TryParse(txtEventTime.Text, out eventTime);
            eventDate = txtEventDate.Text;
            eventVenue = txtEventVenue.Text;
            int.TryParse(txtPeopleCap.Text, out eventCapacity);
            eventAdditional = txtAdditional.Text;

            //When this form is loaded/displayed the label must not be visible.
            lblResponce.Visible = false;

            //When this form is loaded, the venue data must be displayed.
            //Try catch to throw exceptions.
            try
            {
                //What must be displayed on the dataEventVenues datagrid.
                conn.Open();
                string displayVenues = @"SELECT *FROM Venues";
                SqlCommand comm = new SqlCommand(displayVenues, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = comm;
                adapter.Fill(dtset, "Venues");

                dataEventVenues.DataSource = dtset;
                dataEventVenues.DataMember = "Venues";
                conn.Close();

                //Code that must display data on the dataEvents datagrid.
                conn.Open();
                string displayHost = @"SELECT *FROM Events";
                SqlCommand command = new SqlCommand(displayHost, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(dtset, "Events");

                dataEvents.DataSource = dtset;
                dataEvents.DataMember = "Events";

                conn.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }

            

        }

        private void btnInsertData_Click(object sender, EventArgs e)
        {
            //Inserting data into the datagridview.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string insertEventData = $"INSERT INTO Events VALUES('{txtEventID.Text}', '{txtEventName.Text}', '{txtEventDescription.Text}', '{txtEventDate.Text}', '{txtEventTime.Text}', '{txtEventVenue.Text}', '{txtPeopleCap.Text}', '{txtAdditional.Text}')";
                SqlCommand cmmand = new SqlCommand(insertEventData, conn);
                adapter = new SqlDataAdapter();

                adapter.InsertCommand = cmmand;
                adapter.InsertCommand.ExecuteNonQuery();

                //insertEventData.Rows.Add(eventName, eventDescri, eventDate, eventVenue, eventCapacity, eventAdditional);

                conn.Close();
                lblResponce.Visible = true;
                lblResponce.Text = "Event is inserted successfully.";

                //Calling the insert method.
                InsertData();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnUpdateData_Click(object sender, EventArgs e)
        {
            //Updating data from the datagridview.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string updateEventData = $"UPDATE Events set Id ='" + txtEventID.Text + "' , Name= ' " + txtEventName.Text + "' , Description= ' " + txtEventDescription.Text + "' , Date= ' " + txtEventDate.Text + "' , Time= ' " + 
                    txtEventTime.Text + "' , Venue= ' " + txtEventVenue.Text + "' , EventCapacity= ' " + txtPeopleCap.Text + "' , AdditionalInfo= ' " + txtAdditional.Text + " ' ";
                SqlCommand comm = new SqlCommand(updateEventData, conn);

                adapter.UpdateCommand = comm;
                adapter.UpdateCommand.ExecuteNonQuery();

                conn.Close();

                lblResponce.Visible = true;
                lblResponce.Text = "Event is updated successfully.";

                //Calling the update method.
                UpdateData();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnDeleteData_Click(object sender, EventArgs e)
        {
            //Deleting data in the datagridview.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string deleteEventData = $"DELETE FROM Events WHERE Name = '" + txtEventName.Text + "'";
                SqlCommand cmmand = new SqlCommand(deleteEventData, conn);
                adapter = new SqlDataAdapter();

                adapter.InsertCommand = cmmand;
                adapter.InsertCommand.ExecuteNonQuery();
                conn.Close();

                lblResponce.Visible = true;
                lblResponce.Text = "Event is deleted successfully.";

                //Calling the deletedata method to update.
                deleteData();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            //When the back label is seleted or clicked Form1 must be loaded or displayed.
            this.Hide();//When the button back is clicked, this form must be hidden/closed.
            Form1 frmBack = new Form1();
            frmBack.ShowDialog();
        }
        private void InsertData()
        {
            //Try catch to throw exceptions.
            try
            {
                //Code that must display data on the dataEvents datagrid.
                conn.Open();
                string displayHost = @"SELECT *FROM Events";
                SqlCommand command = new SqlCommand(displayHost, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(dtset, "Events");

                dataEvents.DataSource = dtset;
                dataEvents.DataMember = "Events";

                conn.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void deleteData()
        {
            //Try catch to throw exceptions.
            try
            {
                //Code that must display data on the dataEvents datagrid.
                conn.Open();
                string displayHost = @"SELECT *FROM Events";
                SqlCommand command = new SqlCommand(displayHost, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(dtset, "Events");

                dataEvents.DataSource = dtset;
                dataEvents.DataMember = "Events";

                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void UpdateData()
        {
            //Try catch to throw exceptions.
            try
            {
                //Code that must display data on the dataEvents datagrid.
                conn.Open();
                string displayHost = @"SELECT *FROM Events";
                SqlCommand command = new SqlCommand(displayHost, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(dtset, "Events");

                dataEvents.DataSource = dtset;
                dataEvents.DataMember = "Events";

                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
