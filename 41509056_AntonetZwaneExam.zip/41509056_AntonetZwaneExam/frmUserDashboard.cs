﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _41509056_AntonetZwaneExam
{
    public partial class frmUserDashboard : Form
    {
        //Connecting the database.
        DataSet dtset;
        SqlDataAdapter adapter;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True");
        public frmUserDashboard()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            //When the back label is seleted or clicked Form1 must be loaded or displayed.
            this.Hide();//When the button back is clicked, this form must be hidden/closed.
            Form1 frmDash = new Form1();
            frmDash.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //When the button is clicked, frmRegisteredEvents must be displayed.
            frmRegisteredEvents showForm = new frmRegisteredEvents();
            showForm.ShowDialog();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
            //An if statement to check for premium user password.
            if(txtHostPass.Text != "Premium32" || txtHostUser.Text != "Host")
            {
                MessageBox.Show("Enter valid username or password.");
            }
            else if(txtHostPass.Text == "Premium32" || txtHostUser.Text == "Host")
            {
                // When this button is clicked, the frmHostManage must be displayed.
                frmHostManage showHost = new frmHostManage();
                showHost.ShowDialog();
            }
        }

        private void rdbPremium_CheckedChanged(object sender, EventArgs e)
        {
            //Try catch to throw exceptions.
            try
            {
                //When this radio button is clicked the button to login into premium membership must be visible.
                btnPremium.Visible = true;
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void frmUserDashboard_Load(object sender, EventArgs e)
        {
            //When this form is loaded/displayed the premium button must not be visible.
            btnPremium.Visible = false;

            //Connecting the database.
            string connectData;
            connectData = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True";
            conn = new SqlConnection(connectData);

            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string displayUser = @"SELECT *FROM Users";
                SqlCommand comm = new SqlCommand(displayUser, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = comm;
                adapter.Fill(dtset, "Users");

                dataUser.DataSource = dtset;
                dataUser.DataMember = "Users";

                conn.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnUserUpdate_Click(object sender, EventArgs e)
        {
            //User updates information and change premium if they want to.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string updateEventData = $"UPDATE Users set ID ='" + txtIdNumber.Text + "' , NameSurname= ' " + txtNameSur.Text  + "' , PhoneNumber= ' " + txtPhoneNumber.Text + "' , Membership= ' " + txtMembership.Text + " ' ";
                SqlCommand comm = new SqlCommand(updateEventData, conn);

                adapter.UpdateCommand = comm;
                adapter.UpdateCommand.ExecuteNonQuery();

                conn.Close();
                MessageBox.Show("User information updated successfully.");

                //Calling the update method.
                userUpdate();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnUserInsert_Click(object sender, EventArgs e)
        {
            //User inserts information .
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string insertEventData = $"INSERT INTO Users VALUES('{txtIdNumber.Text}', '{txtNameSur.Text}', '{txtMembership.Text}', '{txtPhoneNumber.Text}')";
                SqlCommand cmmand = new SqlCommand(insertEventData, conn);
                adapter = new SqlDataAdapter();

                adapter.InsertCommand = cmmand;
                adapter.InsertCommand.ExecuteNonQuery();
                MessageBox.Show("User information inserted successfully.");

                conn.Close();

                //Calling the method.
                UserInsert();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
        private void UserInsert()
        {
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string displayUser = @"SELECT *FROM Users";
                SqlCommand comm = new SqlCommand(displayUser, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = comm;
                adapter.Fill(dtset, "Users");

                dataUser.DataSource = dtset;
                dataUser.DataMember = "Users";

                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            try
            {
                //Message that must show when a password is changed succdfully.
                MessageBox.Show("Password changed successfully.");
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message); ;
            }
        }
        
        private void userUpdate()
        {
            //Update method.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string displayUser = @"SELECT *FROM Users";
                SqlCommand comm = new SqlCommand(displayUser, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = comm;
                adapter.Fill(dtset, "Users");

                dataUser.DataSource = dtset;
                dataUser.DataMember = "Users";

                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
