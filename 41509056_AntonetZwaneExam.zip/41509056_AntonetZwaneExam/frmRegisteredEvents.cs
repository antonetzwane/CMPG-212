﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _41509056_AntonetZwaneExam
{
    public partial class frmRegisteredEvents : Form
    {
        //Connecting the database.
        DataSet dtset;
        SqlDataAdapter adapter;
        SqlConnection conn = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True");

        public frmRegisteredEvents()
        {
            InitializeComponent();
        }

        private void dataGrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void frmRegisteredEvents_Load(object sender, EventArgs e)
        {
            //Connecting the database.
            string connectData;
            connectData = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DataEvent.mdf;Integrated Security=True";
            conn = new SqlConnection(connectData);

            // Code that must display data on the dataEvents datagrid when this form is loaded.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string displayData = @"SELECT *FROM Events";
                SqlCommand command = new SqlCommand(displayData, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = command;
                adapter.Fill(dtset, "Events");

                dataGrid.DataSource = dtset;
                dataGrid.DataMember = "Events";

                conn.Close();
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            //When the back label is seleted or clicked Form1 must be loaded or displayed.
            this.Hide();//When the button back is clicked, this form must be hidden/closed.
            Form1 frmShow = new Form1();
            frmShow.ShowDialog();
        }

        private void btnSearchEvents_Click(object sender, EventArgs e)
        {
            //When this button is clicked, data from the datagrid must be filtered.
            //Try catch to throw exceptions.
            try
            {
                conn.Open();
                string eventSearch = $"SELECT *FROM Events WHERE Name LIKE '%" + txtSearchEvent.Text + "%'";
                SqlCommand cmm = new SqlCommand(eventSearch, conn);
                adapter = new SqlDataAdapter();
                dtset = new DataSet();

                adapter.SelectCommand = cmm;
                adapter.Fill(dtset, "Events");

                dataGrid.DataSource = dtset;
                dataGrid.DataMember = "Events";

                conn.Close();
            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            //When this button is clicked information must be displayed in the listbox.
            //Try catch to throw exceptions.
            try
            {
                int registerEvent = dataGrid.SelectedRows.Count;
                int i = 0;

                //A while loop for selected items on the datagrid.
                    while (i < registerEvent)
                    {
                        DataGridViewRow row = dataGrid.SelectedRows[i];

                        //price = Convert.ToDouble(row.Cells["Prices"].Value);

                        //total += price + Convert.ToDouble(row.Cells["Prices"].Value);
                        i++;
                    }


                //What the listbox must display.
                listEvents.Items.Add("\n******************************************************");
                listEvents.Items.Add("EventConnect");
                listEvents.Items.Add("534 Spark Evanue");
                listEvents.Items.Add("Johannesburg");
                listEvents.Items.Add("eventconnect@gmail.com");
                listEvents.Items.Add("P.O Box 432\n");
                listEvents.Items.Add("");
                listEvents.Items.Add("");
                listEvents.Items.Add("");

                listEvents.Items.Add("\n*****THIS IS A FORMAL RECEIPT OR INVOICE OF THE REGISTERED EVENT.******\n");
                listEvents.Items.Add("");//The nextline or to create a line.
                listEvents.Items.Add("");

                listEvents.Items.Add("You registered for this event:");

                //Items that are selected and must be displayed in the listbox.
                List<string> selectedItems = new List<string>();
                foreach (var item in listEvents.SelectedItems)
                {
                    selectedItems.Add(item.ToString());
                }


                listEvents.Items.Add("\nCongradulations. You Have Successully Registered an event!!");
                listEvents.Items.Add("*****Thank you for choosing EventConnect.******\n");
                //Message to display when a user clicks this button.
                MessageBox.Show("Successfully registered event.");

            }
            catch(Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void dataGrid_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //This is what must be displayed when an event is selected or clicked in the datagrid.
            //Try catch to throw exceptions.
            try
            {
                if (e.RowIndex >= 0)
                {
                    //When the row is selected or clicked, it must be displayed on the listbox.
                    DataGridViewRow registerRow = this.dataGrid.Rows[e.RowIndex];
                    listEvents.Items.Add(registerRow.Cells[0].Value.ToString() + "\t" + registerRow.Cells[1].Value.ToString() + "\t" + registerRow.Cells[2].Value.ToString() + "\t" + registerRow.Cells[3].Value.ToString()
                        + "\t" + registerRow.Cells[4].Value.ToString() + "\t" + registerRow.Cells[5].Value.ToString() + "\t" + registerRow.Cells[6].Value.ToString() + "\t" + registerRow.Cells[7].Value.ToString());
                }
            }
            catch (Exception error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
